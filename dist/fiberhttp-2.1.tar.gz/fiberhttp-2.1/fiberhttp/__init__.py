from .client_file import client
from .methods import get, post, put, delete
# from os import path
# from sys import path as syspath

# syspath.append(path.abspath(path.dirname(__file__)))